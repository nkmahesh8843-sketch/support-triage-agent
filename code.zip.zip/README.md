# Support Triage Agent (Multi-Domain)

## 📌 Overview

This project implements a terminal-based support triage agent that processes customer support tickets across multiple domains. The system classifies incoming tickets, retrieves relevant documentation, and decides whether to respond automatically or escalate to a human agent.

---

## ⚙️ Features

* Ticket classification (request type & product area)
* Safety-first decision engine (REPLY vs ESCALATE)
* TF-IDF based document retrieval
* Confidence-based reasoning
* Fully grounded responses (no hallucination)
* Detailed logging and traceability

---

## 🧠 Approach

### 1. Classification

Each ticket is analyzed to determine:

* Request type (e.g., bug_report, fraud_report, how_to_question)
* Product area (e.g., billing, technical, account_access)

---

### 2. Retrieval

Relevant support documents are retrieved using a TF-IDF vectorizer to ensure responses are grounded in the provided corpus.

---

### 3. Decision Engine

The system applies rule-based logic:

* Sensitive categories (fraud, billing, account access) → ESCALATE
* Low confidence → ESCALATE
* Safe queries with sufficient confidence → REPLY

---

### 4. Response Generation

* Responses are generated only from retrieved documents
* Includes contextual grounding (product area)
* Avoids hallucination or unsupported claims

---

## 🛡️ Safety Measures

* Mandatory escalation for sensitive issues
* Confidence threshold to prevent unsafe responses
* No external APIs or data sources used

---

## ▶️ How to Run

1. Navigate to project directory
2. Activate virtual environment (if used)
3. Run:

```bash
python main.py
```

---

## 📂 Input & Output

* Input: `data/support_issues.csv`
* Output: `output/triage_results.csv`
* Logs: `logs/log.txt`

---

## 🚀 Future Improvements

* Semantic search using embeddings
* Improved classification model
* Multilingual support
* Feedback-based learning system

---

## ✅ Conclusion

This system ensures safe, explainable, and grounded support automation by combining rule-based decision-making with document retrieval.
